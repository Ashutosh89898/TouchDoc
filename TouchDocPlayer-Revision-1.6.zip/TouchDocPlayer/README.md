# TouchDoc 1.6 — Android document player

TouchDoc is an Android WebView-based document viewer for PDF, PPTX and supported media files. The project preserves the existing TouchDoc 1.4 interface and features, including Android “Open with” support, document search, font controls for PowerPoint text, continuous page/slide reading and the compact right-edge page scrubber.

## Revision 1.5 changes

- Native touch scrolling is kept in the document flow in portrait and landscape.
- Orientation changes trigger a reader reflow and retain the current page/slide rather than returning to the home screen.
- PDF and PPTX render-scale minimums are lowered to 1% of the fit scale. PPTX no longer has a 250 px minimum slide width, so it can zoom out below the viewport width.
- Added a custom TouchDoc adaptive launcher icon and density-specific fallback icons.
- Android version metadata is now `versionCode 6`, `versionName 1.6`.

## Build and install in Termux

1. Extract this project ZIP.
2. In Termux, enter the folder containing `settings.gradle`.
3. Run:

```sh
bash build.sh
```

The script runs `gradle assembleDebug`, copies the APK to `~/storage/downloads/TouchDoc-1.5.apk` (when Termux storage is configured), and opens the Android package installer. If storage access has not been configured, run `termux-setup-storage` and retry.

Manual build command:

```sh
gradle assembleDebug
```

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Notes

- The app uses Android WebView and requires an internet connection to load the existing PDF.js and JSZip CDN libraries used by the document renderer.
- This is a debug APK build, suitable for direct installation/testing. It is not a Play Store-signed release build.
