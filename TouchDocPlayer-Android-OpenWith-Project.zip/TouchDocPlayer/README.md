# TouchDoc Player — Android project (continuous viewer + Open with)

This Android Studio project wraps the TouchDoc continuous-scroll HTML viewer in a native Android WebView.

## Included
- PDF and PPTX continuous vertical scrolling (no page-by-page swipe navigation).
- Zoom controls and live page/slide position indicator.
- Internet access retained for PDF.js and JSZip CDN libraries.
- Android `ACTION_VIEW` intent filters for PDF, PPTX and legacy PPT MIME types.
- Opens files selected from Android My Files using **Open with → TouchDoc Player**.
- Native file picker remains available inside the app.

## Build APK
1. Open this folder in Android Studio.
2. Allow Gradle sync and install Android SDK Platform 35 if requested.
3. Build → Build Bundle(s) / APK(s) → Build APK(s).
4. Install the debug APK on your phone.
5. In My Files, open a PDF/PPTX → Open with → TouchDoc Player. Android may offer Just once / Always where supported.

## Notes
- This ZIP is Android source code, not a prebuilt APK. Build it in Android Studio.
- PDF.js and JSZip load from public CDNs, so internet access is required for document rendering.
- Android passes shared document bytes into the WebView through a JavaScript bridge. Very large files may use significant memory.
- Rendering fidelity for advanced PowerPoint effects is not identical to Microsoft PowerPoint.
