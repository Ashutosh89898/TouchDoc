# TouchDoc 1.7 — Android document player

TouchDoc is an Android WebView-based document viewer for PDF, PPTX and supported media files.

## Revision 1.7 — smoother, proportional pinch zoom

- Pinch zoom now updates live while the two fingers move; it no longer waits for the fingers to be lifted before showing the zoom.
- The preview scales the complete document surface uniformly, preserving the relative size and position of text, images, shapes, diagrams and whitespace.
- Zoom commits at the selected scale after the gesture. PDF pages are re-rendered at that scale for improved clarity rather than leaving the original low-resolution canvas enlarged.
- The current page and its approximate on-screen position are retained when the final render/layout is applied.
- The PDF render resolution ceiling was raised moderately while retaining per-page pixel and dimension limits to reduce the risk of excessive memory use on phones.
- Existing search, font controls, page scrubber, document flow, orientation behaviour, launcher icon and Android Open-with support are retained.

## Build and install in Termux

1. Extract this ZIP.
2. In Termux, enter the `TouchDocPlayer` folder (the folder containing `settings.gradle`).
3. Run:

```sh
bash build.sh
```

The script runs `gradle --no-daemon assembleDebug`, copies the APK to `~/storage/downloads/TouchDoc-1.7.apk` when Termux storage is configured, and attempts to open the Android installer.

If storage access has not been configured, run:

```sh
termux-setup-storage
```

Then run `bash build.sh` again.

Manual build command:

```sh
gradle --no-daemon assembleDebug
```

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Notes

- PDF rendering uses PDF.js on canvas. Zooming triggers a higher-resolution page render; this improves clarity substantially, but it is not a true infinite-resolution SVG/vector renderer for every PDF element.
- The app uses CDN-hosted PDF.js and JSZip libraries, so an internet connection is required for those libraries to load.
- This is a debug APK suitable for direct installation/testing, not a Play Store release-signed build.
