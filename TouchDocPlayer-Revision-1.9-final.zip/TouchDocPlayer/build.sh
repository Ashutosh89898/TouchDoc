#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle is not installed. In Termux run: pkg install gradle"
  exit 1
fi

echo "Building TouchDoc 1.9…"
gradle --no-daemon assembleDebug

APK="app/build/outputs/apk/debug/app-debug.apk"
if [[ ! -f "$APK" ]]; then
  echo "Build finished but APK was not found at: $APK"
  exit 1
fi

DEST="$APK"
if [[ -d "$HOME/storage/downloads" && -w "$HOME/storage/downloads" ]]; then
  DEST="$HOME/storage/downloads/TouchDoc-1.9.apk"
  cp -f "$APK" "$DEST"
elif [[ -d /sdcard/Download && -w /sdcard/Download ]]; then
  DEST="/sdcard/Download/TouchDoc-1.9.apk"
  cp -f "$APK" "$DEST"
else
  echo "Storage access is not configured. Run termux-setup-storage, then run this script again."
  echo "APK is still available at: $APK"
  exit 0
fi

echo "APK ready: $DEST"
if command -v termux-open >/dev/null 2>&1; then
  termux-open "$DEST" || true
fi
