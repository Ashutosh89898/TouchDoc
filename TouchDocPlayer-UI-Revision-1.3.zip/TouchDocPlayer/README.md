# TouchDoc Player — Android project (continuous viewer + Open with)

This Android Studio project wraps the TouchDoc continuous-scroll HTML viewer in a native Android WebView.

## Included
- PDF and PPTX continuous vertical scrolling (no page-by-page swipe navigation).
- Zoom controls and live page/slide position indicator.
- Internet access retained for PDF.js and JSZip CDN libraries.
- Android `ACTION_VIEW` intent filters for PDF, PPTX and legacy PPT MIME types.
- Opens files selected from Android My Files using **Open with → TouchDoc Player**.
- Native file picker remains available inside the app.

## Build APK
1. Open this folder in Android Studio.
2. Allow Gradle sync and install Android SDK Platform 35 if requested.
3. Build → Build Bundle(s) / APK(s) → Build APK(s).
4. Install the debug APK on your phone.
5. In My Files, open a PDF/PPTX → Open with → TouchDoc Player. Android may offer Just once / Always where supported.

## Notes
- This ZIP is Android source code, not a prebuilt APK. Build it in Android Studio.
- PDF.js and JSZip load from public CDNs, so internet access is required for document rendering.
- Android passes shared document bytes into the WebView through a JavaScript bridge. Very large files may use significant memory.
- Rendering fidelity for advanced PowerPoint effects is not identical to Microsoft PowerPoint.


## Version 1.2 UI revision
- Minimal sticky header shows the opened filename beside the TouchDoc logo.
- Compact A− / A+ controls adjust PowerPoint text font size independently of slide sizing.
- Removed the viewer back/header row, zoom toolbar, fit controls, and fixed bottom footer.
- Android WebView pinch zoom is enabled with browser zoom buttons hidden.
- PDF pages retain their original fixed-page layout; use pinch gestures to magnify them. The font-size controls specifically adjust editable PPTX text runs.


## Revision 1.3 changes
- Added a compact vertical page scrubber on the right edge for multi-page PDFs and PPTX files.
- Added Android activity configuration handling for orientation and screen-size changes so the WebView is not recreated on rotation.
- Added reader reflow that attempts to retain the current PDF page / PPTX slide after viewport changes.
- Added top safe-area spacing for the Android status bar / camera cutout area.
- Removed the PDF page width cap and lowered the renderer's internal minimum zoom scale so pages can render narrower than the viewport.
