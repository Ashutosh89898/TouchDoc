package com.ashu.touchdoc;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.graphics.Color;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private static final int PICK_FILE = 42;
    private Uri sharedUri;
    private String sharedName = "Shared document";
    private String sharedMime = "";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(12, 14, 20));
        getWindow().setNavigationBarColor(Color.rgb(12, 14, 20));
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(12,14,20));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        // Enable native pinch-to-zoom without showing browser zoom buttons.
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new SharedFileBridge(), "TouchDocAndroid");
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/pdf", "application/vnd.openxmlformats-officedocument.presentationml.presentation", "application/vnd.ms-powerpoint", "video/*", "image/gif"});
                startActivityForResult(intent, PICK_FILE);
                return true;
            }
        });
        web.setWebViewClient(new WebViewClient());
        setContentView(web);
        captureSharedIntent(getIntent());
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        captureSharedIntent(intent);
        if (web != null) web.post(() -> web.evaluateJavascript("window.dispatchEvent(new Event('load'))", null));
    }

    private void captureSharedIntent(Intent intent) {
        if (intent == null || !Intent.ACTION_VIEW.equals(intent.getAction())) return;
        sharedUri = intent.getData();
        if (sharedUri == null) return;
        sharedMime = getContentResolver().getType(sharedUri);
        sharedName = queryName(sharedUri);
    }

    private String queryName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) return c.getString(i);
            }
        } catch (Exception ignored) {}
        String last = uri.getLastPathSegment();
        return last == null ? "Shared document" : last;
    }

    private class SharedFileBridge {
        @JavascriptInterface public boolean hasSharedFile() { return sharedUri != null; }
        @JavascriptInterface public String getSharedFileName() { return sharedName; }
        @JavascriptInterface public String getSharedFileMime() { return sharedMime == null ? "" : sharedMime; }
        @JavascriptInterface public String getSharedFileBase64() {
            if (sharedUri == null) return "";
            try (InputStream in = getContentResolver().openInputStream(sharedUri); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                if (in == null) return "";
                byte[] buffer = new byte[32768]; int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
            } catch (Exception e) { return ""; }
        }
        @JavascriptInterface public void clearSharedFile() { sharedUri = null; sharedName = "Shared document"; sharedMime = ""; }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE && fileCallback != null) {
            Uri[] result = resultCode == RESULT_OK && data != null ? new Uri[]{data.getData()} : null;
            fileCallback.onReceiveValue(result); fileCallback = null;
        }
    }
    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
